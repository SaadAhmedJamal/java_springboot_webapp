package com.example.application.views.home;

import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H4;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.EmailField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.vaadin.lineawesome.LineAwesomeIconUrl;

@PageTitle("home")
@Route("")
@Menu(order = 0, icon = LineAwesomeIconUrl.ARROWS_ALT_V_SOLID)
public class HomeView extends Composite<VerticalLayout> {

    public HomeView() {
        H1 h1 = new H1();
        H4 h4 = new H4();
        Button buttonPrimary = new Button();
        TextField textField = new TextField();
        EmailField emailField = new EmailField();
        getContent().setWidth("100%");
        getContent().getStyle().set("flex-grow", "1");
        h1.setText("My App PhD First Serve");
        h1.setWidth("max-content");
        h4.setText("Computer Science");
        h4.setWidth("max-content");
        buttonPrimary.setText("Start");
        buttonPrimary.setWidth("min-content");
        buttonPrimary.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        textField.setLabel("Name");
        textField.setWidth("min-content");
        emailField.setLabel("Email");
        emailField.setWidth("min-content");
        getContent().add(h1);
        getContent().add(h4);
        getContent().add(buttonPrimary);
        getContent().add(textField);
        getContent().add(emailField);
    }
}
